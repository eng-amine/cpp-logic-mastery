#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <iomanip>


using namespace std;
void Login();
void ShowMainMenue();
void ShowWithDrawScreen();
void GoBackToMainMenue();
void ShowQuickMenue();

string filename = "Client.txt";

struct stData
{
    string accnumber; string pincode; string name; string phonenumber; double accbalance; bool markfordelet = false;
};

stData CurrentUser;

vector<string> SplitString(string S1, string Delim)
{
    vector<string> vString;
    short pos = 0;
    string sWord; // define a string variable 
    // use find() function to get the position of the delimiters 
    while ((pos = S1.find(Delim)) != std::string::npos)
    {
        sWord = S1.substr(0, pos); // store the word  
        if (sWord != "")
        {
            vString.push_back(sWord);
        }
        S1.erase(0, pos + Delim.length());  /* erase() until positon and move to next word. */
    }
    if (S1 != "")
    {
        vString.push_back(S1); // it adds last word of the string.   
    }
    return vString;
}

string ConverRecordToLine(stData data, string delim = "#//#")
{
    string line = "";
    line += data.accnumber + delim;
    line += data.pincode + delim;
    line += data.name + delim;
    line += data.phonenumber + delim;
    line += to_string(data.accbalance);
    return line;
}

stData ConverLineToRecord(string Line, string Seperator = "#//#")
{
    stData Client;
    vector<string> vClientData;
    vClientData = SplitString(Line, Seperator);
    Client.accnumber = vClientData[0];
    Client.pincode = vClientData[1];
    Client.name = vClientData[2];
    Client.phonenumber = vClientData[3];
    Client.accbalance = stod(vClientData[4]);//cast string to double
    return Client;
}

vector<stData> LoadDataFromFile(string filename)
{
    vector<stData> FileContent;

    fstream myfile;
    myfile.open(filename, ios::in);

    if (myfile.is_open())
    {
        string line;
        stData data;
        while (getline(myfile, line))
        {
            data = ConverLineToRecord(line);
            FileContent.push_back(data);
        }
        myfile.close();
    }
    return FileContent;
}

void PrintClientCard(stData Client)
{
    cout << "\nThe following are the client details:\n";
    cout << "\n----------------------------------------";
    cout << "\nAccout Number: " << Client.accnumber;
    cout << "\nPin Code     : " << Client.pincode;
    cout << "\nName         : " << Client.name;
    cout << "\nPhone        : " << Client.phonenumber;
    cout << "\nAccount Balance: " << Client.accbalance << endl;
    cout << "----------------------------------------\n";

}

bool FindClientByAccountNumber(string accnumber, stData& client, string pincode)
{
    vector<stData> data = LoadDataFromFile(filename);
    for (stData i : data)
    {
        if (i.accnumber == accnumber && i.pincode == pincode)
        {
            client = i;
            return true;
        }
    }
    return false;
}

string ReadAcountNumber()
{
    string n;
    cout << "Enter Account Numuber?   ";
    cin >> n;
    return n;
}

string ReadPincode()
{
    string n;
    cout << "Enter another Account Numuber?   ";
    cin >> n;
    return n;
}


void SaveDataLineToFile(string filename, vector<stData> data)
{
    fstream myfile;
    myfile.open(filename, ios::out);

    if (myfile.is_open())
    {
        for (stData m : data)
        {
            myfile << ConverRecordToLine(m) << endl;
        }
    }
    myfile.close();
}

void performDeposit(stData& data)
{
    short amount;
    char y = ' ';
    cout << "Please enter deposit amount    ";
    cin >> amount;

    cout << "\n\nAre you sure do you want to performe this transaction? y/n ";
    cin >> y;
    if (tolower(y) == 'y')
    {
        data.accbalance += amount;
        cout << "\nDone secssesfully new balance is: " << data.accbalance << endl;
    }
}

void Deposit()
{
    vector<stData> data = LoadDataFromFile(filename);

    for (stData & d : data)
    {
        if(d.accnumber == CurrentUser.accnumber)
            performDeposit(d);
    }
   
    SaveDataLineToFile(filename, data);
}

void ShowDepositScreen()
{
    system("cls");
    cout << "----------------------------------------\n";
    cout << "\t  Deposit Screen\n";
    cout << "----------------------------------------\n";

    Deposit();
}


short readAmount(stData data)
{
    short amount;
    char y = ' ';
    do
    {
        cout << "\nEnter an amount multiple of 5's?   ";
        cin >> amount;
    } while (amount % 5 != 0);

    if (amount > data.accbalance)
    {
        cout << "\nThe amount exceeds you balance, make another choice\n";
        system("pause");
        system("cls");
        ShowWithDrawScreen();
    }
    return amount;
}

void performWithDraw(stData& data, short amount)
{
    char y = ' ';
    cout << "\n\nAre you sure do you want to performe this transaction? y/n ";
    cin >> y;
    if (tolower(y) == 'y')
    {
        data.accbalance -= amount;
        cout << "\nDone secssesfully new balance is: " << data.accbalance << endl;
    }
}

void WithDraw(short amount)
{
    vector<stData> data = LoadDataFromFile(filename);

    for (stData& d : data)
    {
        if (d.accnumber == CurrentUser.accnumber)
        {
            performWithDraw(d, amount);
        }
    }

    SaveDataLineToFile(filename, data);
}

void ShowWithDrawScreen()
{
    system("cls");
    cout << "----------------------------------------\n";
    cout << "\t  WithDraw Screen\n";
    cout << "----------------------------------------\n";


    short amount = readAmount(CurrentUser);
    WithDraw(amount);
}


void ShowBalanceScreen()
{
    system("cls");
    cout << "----------------------------------------\n";
    cout << "\t  Check Balance Screen\n";
    cout << "----------------------------------------\n";

    stData client;
    FindClientByAccountNumber(CurrentUser.accnumber, client, CurrentUser.pincode);
    cout << "\nYour Balance is  " << client.accbalance << endl << endl;
}


short ReadQuickMenueOption()
{
    cout << "Choose what to withdraw? [1 to 8]? ";
    short Choice = 0;
    cin >> Choice;
    return Choice;

}

void PerfromQuickMenueOption(short choice)
{
    if (choice == 9)
    {
        GoBackToMainMenue();
    }
    double arr[8] = {20, 50, 100, 200, 400, 600, 800, 1000};

    if (arr[choice - 1] > CurrentUser.accbalance)
    {
        cout << "\nThe amount exceeds you balance, make another choice\n";
        system("pause");
        system("cls");
        ShowQuickMenue();
    }
    WithDraw(arr[choice - 1]);
}

void ShowQuickMenue()
{
    system("cls");
    cout << "===========================================\n";
    cout << "\t\tQuick Withdraw Menue Screen\n";
    cout << "===========================================\n";
    cout << "\t[1] 20 \t\t[2] 50\n";
    cout << "\t[3] 100\t\t[4] 200\n";
    cout << "\t[5] 400\t\t[6] 600\n";
    cout << "\t[7] 800\t\t[8] 1000\n";
    cout << "\t[9] Exit.\n";
    cout << "===========================================\n";
    stData client;
    FindClientByAccountNumber(CurrentUser.accnumber, client, CurrentUser.pincode);
    cout << "\nYour Balance is  " << client.accbalance << endl << endl;

    PerfromQuickMenueOption(ReadQuickMenueOption());
}


enum enMainMenu { QuickWithdraw = 1, Withdraw = 2, deposit = 3, ShowBlance = 4, LogOut = 5};

void GoBackToMainMenue()
{
    system("pause>0");
    ShowMainMenue();
}

short ReadMainMenueOption()
{
    cout << "Choose what do you want to do? [1 to 5]? ";
    short Choice = 0;
    cin >> Choice;
    return Choice;
}

void PerfromMainMenueOption(enMainMenu MainMenueOption)
{
    switch (MainMenueOption)
    {
    case enMainMenu::QuickWithdraw:
    {
        system("cls");
        ShowQuickMenue();
        GoBackToMainMenue();
        break;
    }
    case enMainMenu::Withdraw:
        system("cls");
        ShowWithDrawScreen();
        GoBackToMainMenue();
        break;
    case enMainMenu::deposit:
        system("cls");
        ShowDepositScreen();
        GoBackToMainMenue();
        break;
    case enMainMenu::ShowBlance:
        system("cls");
        ShowBalanceScreen();
        GoBackToMainMenue();
        break;
    case enMainMenu::LogOut:
        system("cls"); // ShowEndScreen();      
        Login();
        break;
    }
}

void ShowMainMenue()
{
    system("cls");
    cout << "===========================================\n";
    cout << "\t\tATM Main Menue Screen\n";
    cout << "===========================================\n";
    cout << "\t[1] Quick Withdraw.\n";
    cout << "\t[2] Withdraw.\n";
    cout << "\t[3] Deposit.\n";
    cout << "\t[4] Chek Balance.\n";
    cout << "\t[5] Logout.\n";
    cout << "===========================================\n";
    PerfromMainMenueOption((enMainMenu)ReadMainMenueOption());
}

bool  LoadClientInfo(string AccNum, string pincode)
{
    if (FindClientByAccountNumber(AccNum, CurrentUser, pincode))
        return true;
    else
        return false;
}

void Login()
{
    bool LoginFaild = false;
    string  accnum, pincode;
    do
    {
        system("cls");
        cout << "\n---------------------------------\n";
        cout << "\tLogin Screen";
        cout << "\n---------------------------------\n";
        if (LoginFaild)
        {
            cout << "Invlaid AccountNumber/PinCode!\n";
        }
        cout << "Enter Account Number? ";
        cin >> accnum;
        cout << "Enter Pin Code? ";
        cin >> pincode;
        LoginFaild = !LoadClientInfo(accnum, pincode);
    } while (LoginFaild);
    ShowMainMenue();
}

int main()
{
    Login();
    system("pause>0");
    return 0;
}