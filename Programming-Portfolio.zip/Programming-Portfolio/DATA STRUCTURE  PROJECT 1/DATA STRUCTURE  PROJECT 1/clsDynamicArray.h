#pragma once

#include <iostream>
using namespace std;

template <class T>
class clsDynamicArray
{
protected:
    int _Size = 0;
    T* _TempArray;

public:
    T* OriginalArray;

    clsDynamicArray(int Size = 0)
    {
        if (Size < 0)
            Size = 0;

        _Size = Size;

        OriginalArray = new T[_Size];
    }

    ~clsDynamicArray()
    {
        delete[]  OriginalArray;
    }

    bool SetItem(int index, T Value)
    {
        if (index >= _Size || _Size < 0)
        {
            return false;
        }

        OriginalArray[index] = Value;
        return true;
    }

    int Size()
    {
        return _Size;
    }

    bool IsEmpty()
    {
        return (_Size == 0);
    }

    void PrintList()
    {
        for (int i = 0; i <= _Size - 1; i++)
        {
            cout << OriginalArray[i] << " ";
        }

        cout << "\n";
    }

    void Resize(int Size)
    {
        if (Size < 0)
            Size == 0;

        _TempArray = new T[Size];

        if (_Size > Size)
            _Size = Size;

        for (int i = 0; i < _Size; i++)
        {
            _TempArray[i] = OriginalArray[i];
        }
        _Size = Size;

        delete[] OriginalArray;
        OriginalArray = _TempArray;
    }

    T GetItem(int Index)
    {
        return OriginalArray[Index];
    }

    void Reverse()
    {
        _TempArray = new T[_Size];

        for (int i = _Size - 1; i >= 0; i--)
        {
            _TempArray[_Size - 1 - i] = OriginalArray[i];
        }
        delete[] OriginalArray;

        OriginalArray = _TempArray;
    }

    void Clear()
    {
        _Size = 0;
        _TempArray = new T[0];
        delete[] OriginalArray;
        OriginalArray = _TempArray;
    }

    bool DeleteItemAt(int index)
    {
        if (index >= _Size || index < 0)
        {
            return false;
        }

        _Size--;

        _TempArray = new T[_Size];

        //copy all before index
        for (int i = 0; i < index; i++)
        {
            _TempArray[i] = OriginalArray[i];
        }

        //copy all after index
        for (int i = index + 1; i < _Size + 1; i++)
        {
            _TempArray[i - 1] = OriginalArray[i];
        }

        delete[] OriginalArray;
        OriginalArray = _TempArray;

        return true;
    }

    void DeleteFirstItem()
    {
        DeleteItemAt(0);
    }

    void DeleteLastItem()
    {
        DeleteItemAt(_Size - 1);
    }

    int Find(T Value)
    {
        for (int i = 0; i < _Size; i++)
        {
            if (OriginalArray[i] == Value) return i;
        }
        return -1;
    }

    bool DeleteItem(T Value)
    {
        int index = Find(Value);

        if (index == -1)
        {
            return false;
        }

        DeleteItemAt(index);
        return true;
    }

    bool InsertAt(T index, T value) {

        if (index > _Size || index < 0)
        {
            return false;
        }

        _Size++;

        _TempArray = new T[_Size];

        //copy all before index
        for (int i = 0; i < index; i++)
        {
            _TempArray[i] = OriginalArray[i];
        }

        _TempArray[index] = value;

        //copy all after index
        for (int i = index; i < _Size - 1; i++)
        {
            _TempArray[i + 1] = OriginalArray[i];
        }

        delete[] OriginalArray;
        OriginalArray = _TempArray;
        return true;

    }

    void InsertAtBeginning(T item)
    {
        InsertAt(0, item);
    }

    void InsertBefore(short index, T item)
    {
        InsertAt(index - 1, item);
    }

    void InsertAfter(short index, T item)
    {
        InsertAt(index + 1, item);
    }

    void InsertAtEnd(T item)
    {
        InsertAt(_Size, item);
    }
};