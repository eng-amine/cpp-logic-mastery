#pragma once
#include <iostream>
#include "clsDate.h"

using namespace std;

class clsInputValidate
{
public:

	static bool IsNumberBetween(float num, float from, float to)
	{
		if (num <= to && num >= from)
			return true;
		else
			return false;
	}

	static bool IsDateBetween(clsDate d1, clsDate d2, clsDate d3)
	{
		if (d1.IsDateAfterDate2(d2) && d3.IsDateAfterDate2(d1))
			return true;
		else if (d1.IsDateAfterDate2(d3) && d2.IsDateAfterDate2(d1))
			return true;
		else
			return false;
	}

	static short ReadIntNumber(string msg)
	{
		short n = 0;
		cin >> n;
		while (cin.fail())
		{ 
			// user didn't input a number
			cin.clear();     
			cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); 
			cout << msg << endl;  
			cin >> n;    
		}
		return n;
	}

	static short ReadIntNumberBetween(short from, short to, string msg)
	{
		short n = ReadIntNumber("\nInvalide number, enter again:");
		while (!(n <= to && n >= from))
		{
			cout << msg;
			n = ReadIntNumber("\nInvalide number, enter again:");
		}
		return n;
	}

	static double ReadDblNumber(string msg)
	{
		double n = 0;
		cin >> n;
		while (cin.fail())
		{
			// user didn't input a number
			cin.clear();
			cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
			cout << msg << endl;
			cin >> n;
		}
		return n;
	}

	static double ReadDblNumberBetween(double from, double to, string msg)
	{
		double n = ReadDblNumber("\nInvalide number, enter again:  ");
		while (!(n <= to && n >= from))
		{
			cout << msg;
			n = ReadDblNumber("\nInvalide number, enter again:  ");
		}
		return n;
	}

	static bool IsValideDate(clsDate d1)
	{
		return d1.IsValid()? true: false;
	}
};

