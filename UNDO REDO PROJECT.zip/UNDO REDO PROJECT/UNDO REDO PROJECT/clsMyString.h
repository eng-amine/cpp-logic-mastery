#pragma once
#include<iostream>
#include<stack>

using namespace std;

class clsMyString
{
	string _Value;
	stack<string> stBafar;

public:
	void SetValue(string value)
	{
		stBafar.push(_Value);
		_Value = value;
	}
	string GetValue()
	{
		return _Value;
	}
	__declspec(property(get = GetValue, put = SetValue)) string Value;

	void Undo()
	{
		_Value = stBafar.top();
		stBafar.pop();
	}

	void Redo()
	{
		stBafar.push(_Value);
	}
};

