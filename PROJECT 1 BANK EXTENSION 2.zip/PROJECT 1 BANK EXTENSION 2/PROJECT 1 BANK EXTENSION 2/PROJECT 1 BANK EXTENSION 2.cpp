#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <iomanip>



using namespace std;
void ShowTransactionsMenuScreen();
void LogInScreen();
void ShowManageUsersMenuScreen();
void ShowMainMenuScreen();


string file2name = "User.txt";
string filename = "Client.txt";

struct stData
{
    string accnumber; string pincode; string name; string phonenumber; double accbalance; bool markfordelet = false;
};

struct permisions
{
    bool showUser = true; bool addUser = true; bool deleteUser = true; bool updateUser = true; bool findUser = true; bool transaction = true; bool manageuser = true;
};

struct stUser
{
    string username; string password; permisions pemitions;  bool markfordelet = false;
};

stUser curentUser;

vector<string> SplitFunc(string str, string delim)
{
    vector<string> vWord;

    short pos = 0;
    string sWord;

    while ((pos = str.find(delim)) != std::string::npos)
    {
        sWord = str.substr(0, pos);

        if (sWord != "")
        {
            vWord.push_back(sWord);
        }
        str.erase(0, pos + delim.length());
    }
    if (str != "")
    {
        vWord.push_back(str);
    }
    return vWord;
}

stData ConverLineToRecord(string line, string delim = "#//#")
{
    stData data;
    vector<string> vData = SplitFunc(line, delim);

    data.accnumber = vData[0];
    data.pincode = vData[1];
    data.name = vData[2];
    data.phonenumber = vData[3];
    data.accbalance = stod(vData[4]);
    return data;
}

string ConverRecordToLine(stData data, string delim = "#//#")
{
    string line = "";
    line += data.accnumber + delim;
    line += data.pincode + delim;
    line += data.name + delim;
    line += data.phonenumber + delim;
    line += to_string(data.accbalance);
    return line;
}

vector<stData> LoadDataFromFile(string filename)
{
    vector<stData> FileContent;

    fstream myfile;
    myfile.open(filename, ios::in);

    if (myfile.is_open())
    {
        string line;
        stData data;
        while (getline(myfile, line))
        {
            data = ConverLineToRecord(line);
            FileContent.push_back(data);
        }
        myfile.close();
    }
    return FileContent;
}

void PrintClientRecord(stData data)
{
    cout << "|" << left << setw(20) << data.accnumber;
    cout << "|" << left << setw(10) << data.pincode;
    cout << "|" << left << setw(35) << data.name;
    cout << "|" << left << setw(18) << data.phonenumber;
    cout << "|" << left << setw(10) << data.accbalance;
}

void PrintClientCard(stData Client)
{
    cout << "\nThe following are the client details:\n";
    cout << "\n----------------------------------------";
    cout << "\nAccout Number: " << Client.accnumber;
    cout << "\nPin Code     : " << Client.pincode;
    cout << "\nName         : " << Client.name;
    cout << "\nPhone        : " << Client.phonenumber;
    cout << "\nAccount Balance: " << Client.accbalance << endl;
    cout << "----------------------------------------\n";

}

bool FindClientByAccountNumber(string accnumber, stData& client, vector<stData> data)
{
    for (stData i : data)
    {
        if (i.accnumber == accnumber)
        {
            client = i;
            return true;
        }
    }
    return false;
}

string ReadAcountNumber()
{
    string n;
    cout << "Enter another Account Numuber?   ";
    cin >> n;
    return n;
}

stData ChangeClientRecord(string accnum)
{
    stData data;
    data.accnumber = accnum;

    cout << "Enter PinCode?   ";
    getline(cin >> ws, data.pincode);

    cout << "Enter Name?   ";
    getline(cin, data.name);

    cout << "Enter Phone number?   ";
    getline(cin, data.phonenumber);

    cout << "Enter Account balance?   ";
    cin >> data.accbalance;

    return data;
}


void PrintAllClientsData(vector<stData> data)
{
    cout << "\n\t\t\t\t\t   Show Clients list\n";
    cout << "------------------------------------------------------------------------------------------------------------------------\n";
    cout << "|" << left << setw(20) << " Account Number";
    cout << "|" << left << setw(10) << " PinCode";
    cout << "|" << left << setw(35) << " Name";
    cout << "|" << left << setw(18) << " PhoneNumber";
    cout << "|" << left << setw(10) << " Account balance \n";
    cout << "________________________________________________________________________________________________________________________\n\n";
    for (stData i : data)
    {
        PrintClientRecord(i);
        cout << endl;
    }
    cout << "________________________________________________________________________________________________________________________\n";
}

void ShowClientList()
{
    vector<stData> data = LoadDataFromFile(filename);
    PrintAllClientsData(data);
}


stData ReadNewClient()
{
    stData data;
    cout << "\nEnter account number?   ";
    getline(cin >> ws, data.accnumber);

    cout << "Enter PinCode?   ";
    getline(cin, data.pincode);

    cout << "Enter Name?   ";
    getline(cin, data.name);

    cout << "Enter Phone number?   ";
    getline(cin, data.phonenumber);

    cout << "Enter Account balance?   ";
    cin >> data.accbalance;

    return data;
}

void SaveDataLineToFile(string filename, string Dataline)
{
    fstream myfile;
    myfile.open(filename, ios::out | ios::app);

    if (myfile.is_open())
    {
        myfile << Dataline << endl;
    }
    myfile.close();
}

void AddNewClent()
{
    vector<stData> vData = LoadDataFromFile(filename);
    string accnum = ReadAcountNumber();
    stData data;
    while (FindClientByAccountNumber(accnum, data, vData))
    {
        cout << "Client with [" << accnum << "] already exist!";
        accnum = ReadAcountNumber();
    }
    data = ChangeClientRecord(accnum);
    string DataLine = ConverRecordToLine(data);
    SaveDataLineToFile(filename, DataLine);
}

void AddClients()
{
    char y = 'y';
    do
    {
        cout << "Adding new client:\n\n";

        AddNewClent();

        cout << "\nClient added succesfully, Do you want to add more client?  ";
        cin >> y;
    } while (tolower(y) == 'y');
}

void ShowAddClientsScreen()
{
    system("cls");
    cout << "----------------------------------------\n";
    cout << "\t  Add New Client Screen\n";
    cout << "----------------------------------------\n";
    AddClients();
}


bool MarkClientForDelet(string accnum, vector<stData>& vData)
{
    for (stData& i : vData)
    {
        if (i.accnumber == accnum)
        {
            i.markfordelet = true;
            return true;
        }
    }
    return false;
}

vector<stData> SaveDataToFile(string filename, vector<stData> vData)
{
    fstream myfile;
    myfile.open(filename, ios::out);
    string dataline;
    if (myfile.is_open())
    {
        for (stData i : vData)
        {
            if (i.markfordelet == false)
            {
                dataline = ConverRecordToLine(i);
                myfile << dataline << endl;
            }
        }
        myfile.close();
    }
    return vData;
}

bool deleteClient(string accnum, vector<stData> vClients)
{
    stData Client;
    char Answer = 'n';
    if (FindClientByAccountNumber(accnum, Client, vClients))
    {
        PrintClientCard(Client);
        cout << "\n\nAre you sure you want delete this client? y/n ? ";
        cin >> Answer;
        if (Answer == 'y' || Answer == 'Y')
        {
            MarkClientForDelet(accnum, vClients);
            SaveDataToFile(filename, vClients);
            //Refresh Clients 
            vClients = LoadDataFromFile(filename);
            cout << "\n\nClient Deleted Successfully.\n";
            return true;
        }
        return true;
    }
    else
    {
        cout << "\nClient with Account Number (" << accnum << ") is Not Found!\n";
        return false;
    }
}

void ShowDeleteClientScreen()
{
    system("cls");
    cout << "----------------------------------------\n";
    cout << "\t  Delete Client Screen\n";
    cout << "----------------------------------------\n";

    vector<stData> vData = LoadDataFromFile(filename);
    string accnum = ReadAcountNumber();

    deleteClient(accnum, vData);
}


bool MarkClientForUpdateByAccountNumber(string AccountNumber, vector <stData>& vClients)
{
    for (stData& C : vClients)
    {
        if (C.accnumber == AccountNumber)
        {
            C.markfordelet = true;
            return true;
        }
    }
    return false;
}

vector <stData> SaveCleintsDataToFile(string FileName, vector<stData> vClients)
{
    fstream MyFile;
    MyFile.open(FileName, ios::out);//overwrite
    string DataLine;
    if (MyFile.is_open())
    {
        for (stData C : vClients)
        {
            DataLine = ConverRecordToLine(C);
            MyFile << DataLine << endl;
        }
        MyFile.close();
    }
    return vClients;
}

bool UpdateClientByAccountNumber(string AccountNumber, vector<stData>& vClients)
{
    stData Client;
    char Answer = 'n';
    if (FindClientByAccountNumber(AccountNumber, Client, vClients))
    {
        PrintClientCard(Client);
        cout << "\n\nAre you sure you want update this client? y/n ? ";
        cin >> Answer;

        if (Answer == 'y' || Answer == 'Y')
        {
            MarkClientForUpdateByAccountNumber(AccountNumber, vClients);

            for (stData& C : vClients)
            {
                if (C.markfordelet == true)
                {
                    C = ChangeClientRecord(AccountNumber);
                    break;
                }
            }

            SaveCleintsDataToFile(filename, vClients);

            //Refresh Clients
            vClients = LoadDataFromFile(filename);
            cout << "\n\nClient Updated Successfully.";
            return true;
        }
    }
    else
    {
        cout << "\nClient with Account Number (" << AccountNumber << ") is Not Found!";
        return false;
    }
}

string ReadClientAccountNumber()
{
    string AccountNumber = "";
    cout << "\nPlease enter AccountNumber? ";
    cin >> AccountNumber;
    return AccountNumber;
}

void ShowUpdateClinetScreen()
{
    system("cls");
    cout << "----------------------------------------\n";
    cout << "\t  Delete Client Screen\n";
    cout << "----------------------------------------\n";

    vector <stData> vClients = LoadDataFromFile(filename);
    string AccountNumber = ReadClientAccountNumber();
    UpdateClientByAccountNumber(AccountNumber, vClients);
}


void ShowFindClientScreen()
{
    system("cls");
    cout << "----------------------------------------\n";
    cout << "\t  Delete Client Screen\n";
    cout << "----------------------------------------\n";

    string accnum = ReadAcountNumber();
    stData client;
    vector<stData> vData = LoadDataFromFile(filename);

    if (FindClientByAccountNumber(accnum, client, vData))
    {
        PrintClientCard(client);
    }
    else
        cout << "\nClient with Account Number (" << accnum << ") is Not Found!";

}







void SaveDataLineToFile(string filename, vector<stData> data)
{
    fstream myfile;
    myfile.open(filename, ios::out);

    if (myfile.is_open())
    {
        for (stData m : data)
        {
            myfile << ConverRecordToLine(m) << endl;
        }
    }
    myfile.close();
}

void performDeposit(stData& data)
{
    short amount;
    char y = ' ';
    cout << "Please enter deposit amount    ";
    cin >> amount;

    cout << "\n\nAre you sure do you want to performe this transaction? y/n ";
    cin >> y;
    if (tolower(y) == 'y')
    {
        data.accbalance += amount;
        cout << "\nDone secssesfully new balance is: " << data.accbalance << endl;
    }
}

void Deposit()
{
    vector<stData> data = LoadDataFromFile(filename);
    string accnum = ReadAcountNumber();
    stData client;

    while (!FindClientByAccountNumber(accnum, client, data))
    {
        cout << "\nClient with Account Number (" << accnum << ") is Not Found!\n";
        accnum = ReadAcountNumber();
    }

    PrintClientCard(client);

    for (stData& d : data)
    {
        if (d.accnumber == client.accnumber)
            performDeposit(d);
    }

    SaveDataLineToFile(filename, data);
}

void ShowDepositScreen()
{
    system("cls");
    cout << "----------------------------------------\n";
    cout << "\t  Deposit Screen\n";
    cout << "----------------------------------------\n";

    Deposit();
}


void performWithDraw(stData& data)
{
    short amount;
    char y = ' ';
    cout << "Please enter withdraw amount    ";
    cin >> amount;

    cout << "\n\nAre you sure do you want to performe this transaction? y/n ";
    cin >> y;
    if (tolower(y) == 'y')
    {
        data.accbalance -= amount;
        cout << "\nDone secssesfully new balance is: " << data.accbalance << endl;
    }
}

void WithDraw()
{
    vector<stData> data = LoadDataFromFile(filename);
    string accnum = ReadAcountNumber();
    stData client;

    while (!FindClientByAccountNumber(accnum, client, data))
    {
        cout << "\nClient with Account Number (" << accnum << ") is Not Found!\n";
        accnum = ReadAcountNumber();
    }

    PrintClientCard(client);

    for (stData& d : data)
    {
        if (d.accnumber == client.accnumber)
            performWithDraw(d);
    }

    SaveDataLineToFile(filename, data);
}

void ShowWithDrawScreen()
{
    system("cls");
    cout << "----------------------------------------\n";
    cout << "\t  WithDraw Screen\n";
    cout << "----------------------------------------\n";

    WithDraw();
}





void PrintClientRecord2(stData data)
{
    cout << "|" << left << setw(30) << data.accnumber;
    cout << "|" << left << setw(40) << data.name;
    cout << "|" << left << setw(50) << data.accbalance;
}

void PrintAllClientsData2(vector<stData> data)
{
    cout << "\n\t\t\t\t\t Balances list\n";
    cout << "------------------------------------------------------------------------------------------------------------------------\n";
    cout << "|" << left << setw(30) << " Account Number";
    cout << "|" << left << setw(40) << " Name";
    cout << "|" << left << setw(20) << " Account balance ";
    cout << "\n________________________________________________________________________________________________________________________\n\n";
    for (stData i : data)
    {
        PrintClientRecord2(i);
        cout << endl;
    }
    cout << "________________________________________________________________________________________________________________________\n";
}

void ShowTotaleBalancesScreen()
{
    vector<stData> data = LoadDataFromFile(filename);
    PrintAllClientsData2(data);

    double m = 0;
    for (stData d : data)
    {
        m += d.accbalance;
    }
    cout << "\n\t\t\t\t\t\t       Totale balances = " << m << endl;
}


enum enChoices2 { deposit = 1, withdraw = 2, totalbalances = 3, mainmenu = 4 };

short ReadClientChoice2()
{
    short c = 0;
    cout << "Choose what do you want to do?  [1 to 4]?     ";
    cin >> c;
    return c;
}

void GoBackToTransactionsMenu()
{
    system("pause");
    system("cls");
    ShowTransactionsMenuScreen();
}

void ClientChoice2()
{
    enChoices2 choice = (enChoices2)ReadClientChoice2();

    switch (choice)
    {
    case enChoices2::deposit:
    {
        system("cls");
        ShowDepositScreen();
        GoBackToTransactionsMenu();
    }
    case enChoices2::withdraw:
    {
        system("cls");
        ShowWithDrawScreen();
        GoBackToTransactionsMenu();
    }
    case enChoices2::totalbalances:
    {
        system("cls");
        ShowTotaleBalancesScreen();
        GoBackToTransactionsMenu();
    }
    case enChoices2::mainmenu:
    {
        system("cls");
        ShowMainMenuScreen();
    }
    }
}

void ShowTransactionsMenuScreen()
{
    cout << "\n===============================================\n";
    cout << "\t\tTransactions Menu Screen\n";
    cout << "===============================================\n";
    cout << "\t[1] Deposit.\n";
    cout << "\t[2] Withdraw.\n";
    cout << "\t[3] Total balances.\n";
    cout << "\t[4] Main menu.\n";
    cout << "===============================================\n";

    ClientChoice2();
}




stUser ConverUserLineToRecord(string line, string delim = "#//#")
{
    stUser data;
    vector<string> vData = SplitFunc(line, delim);

    data.username = vData[0];
    data.password = vData[1];

    return data;
}

string ConvertUserRecordToLine(stUser data, string delim = "#//#")
{
    string line = "";
    line += data.username + delim;
    line += data.password + delim;
    return line;
}

vector<stUser> LoadUserDataFromFile(string filename)
{
    vector<stUser> FileContent;

    fstream myfile;
    myfile.open(filename, ios::in);

    if (myfile.is_open())
    {
        string line;
        stUser data;
        while (getline(myfile, line))
        {
            data = ConverUserLineToRecord(line);
            FileContent.push_back(data);
        }
        myfile.close();
    }
    return FileContent;
}

void PrintUserRecord(stUser data)
{
    cout << "|" << left << setw(20) << data.username;
    cout << "|" << left << setw(10) << data.password;
    cout << "|" << left << setw(10) << 17;
}

void PrintUserCard(stUser Client)
{
    cout << "\nThe following are the client details:\n";
    cout << "---------------------------------------\n";
    cout << "\nAccout Number: " << Client.username;
    cout << "\nAccount Balance: " << Client.password << endl;
    cout << "---------------------------------------\n";
}

bool FindUserByUserName(string accnumber, stUser& client, vector<stUser> data)
{
    for (stUser i : data)
    {
        if (i.username == accnumber)
        {
            client = i;
            return true;
        }
    }
    return false;
}

string ReadUserName()
{
    string n;
    cout << "Enter User Name?   ";
    cin >> n;
    return n;
}

stUser ReadPermitions(stUser user)
{
    char per;

    cout << "\nDo you want to give full acces? y/n    ";
    cin >> per;
    if (tolower(per) != 'y')
    {
        cout << "\nYou can give acces to:\n";

        cout << "Show Users list y/n?  ";
        char per1;
        cin >> per1;
        if (per1 == 'n')
            user.pemitions.showUser = false;
        else
            user.pemitions.showUser = true;

        cout << "Add New User y/n?  ";
        char per2;
        cin >> per2;
        if (per2 == 'n')
            user.pemitions.addUser = false;
        else
            user.pemitions.addUser = true;

        cout << "Delete User y/n?  ";
        char per3;
        cin >> per3;
        if (per3 == 'n')
            user.pemitions.deleteUser = false;
        else
            user.pemitions.deleteUser = true;

        cout << "Update User y/n?  ";
        char per4;
        cin >> per4;
        if (per4 == 'n')
            user.pemitions.updateUser = false;
        else
            user.pemitions.updateUser = true;

        cout << "Find User y/n?  ";
        char per5;
        cin >> per5;
        if (per5 == 'n')
            user.pemitions.findUser = false;
        else
            user.pemitions.findUser = true;
    }
    else
    {
        user.pemitions.showUser = true;
        user.pemitions.addUser = true;
        user.pemitions.deleteUser = true;
        user.pemitions.updateUser = true;
        user.pemitions.findUser = true;
    }
    return user;
}

stUser ChangeUserRecord(string accnum)
{
    stUser data;
    data.username = accnum;

    cout << "Enter a Password?   ";
    getline(cin >> ws, data.password);

    data = ReadPermitions(data);

    return data;
}


void PrintAllUsersData(vector<stUser> data)
{
    cout << "\n\t\t\t\t\t   Show Clients list\n";
    cout << "------------------------------------------------------------------------------------------------------------------------\n";
    cout << "|" << left << setw(20) << " UserName";
    cout << "|" << left << setw(10) << " Password";
    cout << "|" << left << setw(15) << " Permisions";
    cout << "\n________________________________________________________________________________________________________________________\n\n";
    for (stUser i : data)
    {
        PrintUserRecord(i);
        cout << endl;
    }
    cout << "________________________________________________________________________________________________________________________\n";
}

void ShowUsersList()
{
    vector<stUser> data = LoadUserDataFromFile(file2name);
    PrintAllUsersData(data);
}


stUser ReadNewUser()
{
    stUser data;
    cout << "\nEnter Username?   ";
    getline(cin >> ws, data.username);

    cout << "Enter Password?   ";
    getline(cin, data.password);

    return data;
}

void SaveUserDataLineToFile(string filename, string Dataline)
{
    fstream myfile;
    myfile.open(filename, ios::out | ios::app);

    if (myfile.is_open())
    {
        myfile << Dataline << endl;
    }
    myfile.close();
}

void AddNewUser()
{
    vector<stUser> vData = LoadUserDataFromFile(file2name);
    string accnum = ReadUserName();
    stUser data;
    char per;
    while (FindUserByUserName(accnum, data, vData))
    {
        cout << "User with [" << accnum << "] already exist!";
        accnum = ReadUserName();
    }
    data = ChangeUserRecord(accnum);

    string DataLine = ConvertUserRecordToLine(data);
    SaveUserDataLineToFile(file2name, DataLine);
}

void AddUsers()
{
    char y = 'y';
    do
    {
        cout << "Adding new User:\n\n";

        AddNewUser();

        cout << "\nUser added succesfully, Do you want to add more User?  ";
        cin >> y;
    } while (tolower(y) == 'y');
}

void ShowAddUsersScreen()
{
    system("cls");
    cout << "----------------------------------------\n";
    cout << "\t  Add New User Screen\n";
    cout << "----------------------------------------\n";
    AddUsers();
}


bool MarkUserForDelet(string accnum, vector<stUser>& vData)
{
    for (stUser& i : vData)
    {
        if (i.username == accnum)
        {
            i.markfordelet = true;
            return true;
        }
    }
    return false;
}

vector<stUser> SaveUserDataToFile(string file2name, vector<stUser> vData)
{
    fstream myfile;
    myfile.open(file2name, ios::out);
    string dataline;
    if (myfile.is_open())
    {
        for (stUser i : vData)
        {
            if (i.markfordelet == false)
            {
                dataline = ConvertUserRecordToLine(i);
                myfile << dataline << endl;
            }
        }
        myfile.close();
    }
    return vData;
}

bool deleteClient(string accnum, vector<stUser> vClients)
{
    stUser Client;
    char Answer = 'n';
    if (FindUserByUserName(accnum, Client, vClients))
    {
        PrintUserCard(Client);
        cout << "\n\nAre you sure you want delete this client? y/n ? ";
        cin >> Answer;
        if (Answer == 'y' || Answer == 'Y')
        {
            MarkUserForDelet(accnum, vClients);
            SaveUserDataToFile(file2name, vClients);
            //Refresh Clients 
            vClients = LoadUserDataFromFile(file2name);
            cout << "\n\nUser Deleted Successfully.\n";
            return true;
        }
        return true;
    }
    else
    {
        cout << "\nClient with User Name (" << accnum << ") is Not Found!\n";
        return false;
    }
}

void ShowDeleteUserScreen()
{
    system("cls");
    cout << "----------------------------------------\n";
    cout << "\t  Delete User Screen\n";
    cout << "----------------------------------------\n";

    vector<stUser> vData = LoadUserDataFromFile(file2name);
    string accnum = ReadUserName();

    deleteClient(accnum, vData);
}


bool MarkUserForUpdateByUserName(string UserName, vector <stUser>& vClients)
{
    for (stUser& C : vClients)
    {
        if (C.username == UserName)
        {
            C.markfordelet = true;
            return true;
        }
    }
    return false;
}

vector <stUser> SaveUsersDataToFile(string FileName, vector<stUser> vClients)
{
    fstream MyFile;
    MyFile.open(FileName, ios::out);//overwrite
    string DataLine;
    if (MyFile.is_open())
    {
        for (stUser C : vClients)
        {
            DataLine = ConvertUserRecordToLine(C);
            MyFile << DataLine << endl;
        }
        MyFile.close();
    }
    return vClients;
}

bool UpdateUserByUserName(string AccountNumber, vector<stUser>& vClients)
{
    stUser Client;
    char Answer = 'n';
    if (FindUserByUserName(AccountNumber, Client, vClients))
    {
        PrintUserCard(Client);
        cout << "\n\nAre you sure you want update this client? y/n ? ";
        cin >> Answer;

        if (Answer == 'y' || Answer == 'Y')
        {
            MarkUserForUpdateByUserName(AccountNumber, vClients);

            for (stUser& C : vClients)
            {
                if (C.markfordelet == true)
                {
                    C = ChangeUserRecord(AccountNumber);
                    break;
                }
            }

            SaveUsersDataToFile(file2name, vClients);

            //Refresh Clients
            vClients = LoadUserDataFromFile(file2name);
            cout << "\n\nUser Updated Successfully.\n";
            return true;
        }
    }
    else
    {
        cout << "\nUser with User Name (" << AccountNumber << ") is Not Found!\n";
        return false;
    }
}

string ReadUserUserName()
{
    string AccountNumber = "";
    cout << "\nPlease enter UserName? ";
    cin >> AccountNumber;
    return AccountNumber;
}

void ShowUpdateUserScreen()
{
    system("cls");
    cout << "----------------------------------------\n";
    cout << "\t  Delete User Screen\n";
    cout << "----------------------------------------\n";

    vector <stUser> vClients = LoadUserDataFromFile(file2name);
    string AccountNumber = ReadUserUserName();
    UpdateUserByUserName(AccountNumber, vClients);
}


void ShowFindUserScreen()
{
    system("cls");
    cout << "----------------------------------------\n";
    cout << "\t  Delete User Screen\n";
    cout << "----------------------------------------\n";

    string accnum = ReadUserName();
    stUser client;
    vector<stUser> vData = LoadUserDataFromFile(file2name);

    if (FindUserByUserName(accnum, client, vData))
    {
        PrintUserCard(client);
    }
    else
        cout << "\nClient with UserName (" << accnum << ") is Not Found!";

}


enum enUserChoices { showUser = 1, addUser = 2, deleteUser = 3, updateUser = 4, findUser = 5, Mainmenu = 6 };

void showBlockCreen()
{
    cout << "\n---------------------------------------------\n";
    cout << "Access Denied\nYou don't have permission to do this,\nPlease contact your admin.\n";
    cout << "---------------------------------------------\n\n";
}

short ReadUserChoice()
{
    short c = 0;
    cout << "Choose what do you want to do?  [1 to 6]?     ";
    cin >> c;
    return c;
}

void GoBackToManageUsersMenu()
{
    system("pause");
    system("cls");
    ShowManageUsersMenuScreen();
}

void UserChoice()
{
    enUserChoices choice = (enUserChoices)ReadUserChoice();

    switch (choice)
    {
    case enUserChoices::showUser:
    {
        system("cls");
        ShowUsersList();
        GoBackToManageUsersMenu();
    }
    case enUserChoices::addUser:
    {
        system("cls");
        ShowAddUsersScreen();
        GoBackToManageUsersMenu();
    }
    case enUserChoices::deleteUser:
    {
        system("cls");
        ShowDeleteUserScreen();
        GoBackToManageUsersMenu();
    }
    case enUserChoices::updateUser:
    {
        system("cls");
        ShowUpdateUserScreen();
        GoBackToManageUsersMenu();
    }
    case enUserChoices::findUser:
    {
        system("cls");
        ShowFindUserScreen();
        GoBackToManageUsersMenu();
    }
    case enUserChoices::Mainmenu:
    {
        system("cls");
        ShowMainMenuScreen();
    }
    }
}

void ShowManageUsersMenuScreen()
{
    cout << system("cls");
    cout << "\n===============================================\n";
    cout << "\t\tManage Users Menu Screen\n";
    cout << "===============================================\n";
    cout << "\t[1] Show Users List.\n";
    cout << "\t[2] Add New User.\n";
    cout << "\t[3] Delete User .\n";
    cout << "\t[4] Update User Info.\n";
    cout << "\t[5] Find User.\n";
    cout << "\t[6] MainMenu.\n";
    cout << "===============================================\n";

    UserChoice();
}




enum enChoices { showclient = 1, addclient = 2, deleteclinet = 3, updateclient = 4, findclient = 5, transactions = 6, manageUsers = 7, Logout = 8};

short ReadClientChoice()
{
    short c = 0;
    cout << "Choose what do you want to do?  [1 to 8]?     ";
    cin >> c;
    return c;
}

void GoBackToManiMenu()
{
    system("pause");
    system("cls");
    ShowMainMenuScreen();
}

void ClientChoice()
{
    enChoices choice = (enChoices)ReadClientChoice();
    stUser user = curentUser;
    switch (choice)
    {
    case enChoices::showclient:
    {
        system("cls");
        if (user.pemitions.showUser == true)
            ShowClientList();

        else
            showBlockCreen();
        GoBackToManiMenu();
    }
    case enChoices::addclient:
    {
        system("cls");
        if (user.pemitions.addUser == true)
            ShowAddClientsScreen();

        else
            showBlockCreen();
        GoBackToManiMenu();
    }
    case enChoices::deleteclinet:
    {
        system("cls");
        if (user.pemitions.deleteUser == true)
            ShowDeleteClientScreen();
        else
            showBlockCreen();
        GoBackToManiMenu();
    }
    case enChoices::updateclient:
    {
        system("cls");
        if (user.pemitions.updateUser == true)
            ShowUpdateClinetScreen();
        else
            showBlockCreen();
        GoBackToManiMenu();
    }
    case enChoices::findclient:
    {
        system("cls");
        if (user.pemitions.findUser == true)
            ShowFindClientScreen();
        else
            showBlockCreen();
        GoBackToManiMenu();
    }
    case enChoices::transactions:
    {
        system("cls");
        if (user.pemitions.transaction == true)
            ShowTransactionsMenuScreen();
        else
            showBlockCreen();
        GoBackToManiMenu();
    }
    case enChoices::manageUsers:
    {
        system("cls");
        if (user.pemitions.manageuser == true)
            ShowManageUsersMenuScreen();
        else
            showBlockCreen();
    }
    case enChoices::Logout:
    {
        system("cls");
        LogInScreen();
    }
    }
}

void ShowMainMenuScreen()
{
    cout << "\n===============================================\n";
    cout << "\t\tMain Menu Screen\n";
    cout << "===============================================\n";
    cout << "\t[1] Show Client List.\n";
    cout << "\t[2] Add New Client.\n";
    cout << "\t[3] Delete Client .\n";
    cout << "\t[4] Update Client Info.\n";
    cout << "\t[5] Find Client List.\n";
    cout << "\t[6] Transactions.\n";
    cout << "\t[7] Manage Users.\n";
    cout << "\t[8] LogOut.\n";
    cout << "===============================================\n";

    ClientChoice();
}


void LogInScreen()
{
    cout << "\n-----------------------------------------------\n";
    cout << "\t\tLogIn Screen\n";
    cout << "_______________________________________________\n";

    string username = ReadUserUserName();
    vector<stUser> Vuser = LoadUserDataFromFile(file2name);

    while (!FindUserByUserName(username, curentUser, Vuser))
    {
        cout << "\nInvalide Password/Username!!!\n";
        username = ReadUserUserName();
    }

    ShowMainMenuScreen();
}

int main()
{
    LogInScreen();
}