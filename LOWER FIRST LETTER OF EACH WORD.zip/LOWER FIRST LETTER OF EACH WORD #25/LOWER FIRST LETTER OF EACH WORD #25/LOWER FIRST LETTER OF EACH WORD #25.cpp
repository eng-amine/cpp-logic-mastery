#include <iostream>
#include <string>


using namespace std;

string ReadString()
{
    string str;
    cout << "Enter your string:\n";
    getline(cin, str);
    return str;
}

string UpperFirstLetter(string S1)
{
    bool isFirstLetter = true;
    cout << "\nString after upper First letters: \n";
    for (short i = 0; i < S1.length(); i++)
    {
        if (S1[i] != ' ' && isFirstLetter)
        {
            S1[i] = toupper(S1[i]);
        }
        isFirstLetter = (S1[i] == ' ' ? true : false);
    }
    return S1;
}

string LowerFirstLetter(string S1)
{
    bool isFirstLetter = true;
    cout << "\nString after lower First letters: \n";
    for (short i = 0; i < S1.length(); i++)
    {
        if (S1[i] != ' ' && isFirstLetter)
        {
            S1[i] = tolower(S1[i]);
        }
        isFirstLetter = (S1[i] == ' ' ? true : false);
    }
    return S1;
}

int main()
{
    string S1 = ReadString();

    cout << UpperFirstLetter(S1) << endl;
    cout << LowerFirstLetter(UpperFirstLetter(S1)) << endl;
}