#pragma once
#include <iostream>
#include "clsUser.h"
clsUser CurrentUser = clsUser::Find("", "");