#pragma once
#include<iostream>
#include"clsMyStack.h"

class clsMyString
{
	clsMyStack <string> Memorie;
	clsMyStack <string> Trash;

	string _value;

public:
	clsMyString()
	{
		Memorie.push(_value);
	}

	void SetValue(string value)
	{
		Memorie.push(value);
		_value = value;
	}
	string GetValue()
	{
		return Memorie.Top();
	}
	_declspec(property(put = SetValue, get = GetValue))string Value;

	void Undo()
	{
		Trash.push(Memorie.Top());
		Memorie.pop();
	}

	void Redo()
	{
		Memorie.push(Trash.Top());
		Trash.pop();
	}
};

